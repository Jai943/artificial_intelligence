Name/UTA-ID - Jayachandra Jarajapu/1001964536
Course level - 5360
___________________________________________________________________________________________________
Code is done in Python 3.10.2
___________________________________________________________________________________________________
Functionalities include :
Usage of heapq (a.k.a priority queue) in managing nodes inside the fringe
Used lists to manage nodes inside fringe and closed
Used dictionaries to manage system arguments and input and heuristic files data
___________________________________________________________________________________________________
Instructions for execution:
Use the following commands in the command prompt to run the code.

For uniformed - ucs search
>python find_route.py input1.txt Bremen Kassel 

For informed  - a* star search
>python find_route.py input1.txt Bremen Kassel h_kassel.txt
___________________________________________________________________________________________________



